^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package astra_launch
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.0 (2016-05-27)
------------------
* initial commit
* Contributors: Len Zhong
