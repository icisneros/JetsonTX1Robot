#!/bin/bash

echo "remap the device serial port(ttyUSBX) to  createbs"
echo "createbs usb connection as /dev/createbs , check it using the command : ls -l /dev|grep ttyUSB"
echo "start copy createbase.rules to  /etc/udev/rules.d/"
echo "`rospack find create_autonomy`/scripts/createbase.rules"
sudo cp `rospack find create_autonomy`/scripts/createbase.rules  /etc/udev/rules.d
echo " "
echo "Restarting udev"
echo ""
sudo service udev reload
sudo service udev restart
echo "finish "
