#!/bin/bash

echo "delete remap the device serial port(ttyUSBX) to  createbs"
echo "sudo rm   /etc/udev/rules.d/createbase.rules"
sudo rm   /etc/udev/rules.d/createbase.rules
echo " "
echo "Restarting udev"
echo ""
sudo service udev reload
sudo service udev restart
echo "finish  delete"
